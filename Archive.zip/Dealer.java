import java.util.Random;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class Dealer {

  public Dealer(){

  }

  public void createDeck(){
    Integer[] deck = new Integer[52];
    for(int k = 0; k < deck.length; k++)
      deck[k] = k + 1;

    Collections.shuffle(Arrays.asList(deck));

    for( int i = 0;i < deck.length; i++) {
      System.out.print(deck[i]+ " " );

    }
  }


  public void dealCards(){
    Scanner user_input = new Scanner( System.in );
    String numPlayers;
    System.out.print("Enter the number of players: ");
    numPlayers = user_input.next( );
    int result = Integer.parseInt(numPlayers);
    int numCardsEach = Math.round(52 / result) ;
    System.out.println(numCardsEach);

  }

}   //end of class





// Card temp;

    // for ( int i = deck.length-1; i > 0; i-- ) {
    //     int rand = (int)(Math.random()*(i+1));
    //     int temp = deck[i];
    //     deck[i] = deck[rand];
    //       deck[rand] = temp;
    //       System.out.println (temp);


    // }

    // Random rnd = new Random();
    // for (int i = deck.length - 1; i > 0; i--)
    // {
    //   int index = rnd.nextInt(i + 1);
    //   // Simple swap
    //   int a = deck[index];
    //   deck[index] = deck[i];
    //   deck[i] = a;
    //   System.out.println (deck[index]);
    // }



     // If running on Java 6 or older, use `new Random()` on RHS here
      //   Random roond = ThreadLocalRandom.current();
      //   for (int i = deck.length - 1; i > 0; i--)
      //   {
      //     int index = roond.nextInt(i + 1);
      //     // Simple swap
      //     int a = deck[index];
      //     deck[index] = deck[i];
      //     deck[i] = a;
      //     System.out.println (deck[index]);
      //   }
      // }






// public void shuffle() {
//         for ( int i = deck.length-1; i > 0; i-- ) {
//             int rand = (int)(Math.random()*(i+1));
//             Card temp = deck[i];
//             deck[i] = deck[rand];
//             deck[rand] = temp;
//         }

//     }    











  //  get numOfPlayers
  //  get numberperdeck = integer of divide 52/numplayers



  //  for i = 1 to numOfPlayers
  //   for j = 1 to to nummerperdeck

  //     add j to i array somewhere

  //   j = j +1
  //   next  
  //   i = i +1
  //   next


  // }

