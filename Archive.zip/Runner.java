class Runner{

  public static void main(String args[]) {
    
    Dealer dealer=new Dealer();
    dealer.createDeck();
    dealer.dealCards();
  }

}